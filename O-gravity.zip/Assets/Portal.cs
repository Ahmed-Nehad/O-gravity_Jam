using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Portal : MonoBehaviour
{
    public Transform destination;
    public float distance;

    private void OnTriggerEnter2D(Collider2D collision) {
        if(Vector2.Distance(transform.position, collision.transform.position) > distance)
            collision.transform.position = destination.position;
    }
}
