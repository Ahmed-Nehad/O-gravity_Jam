using System;
using System.Threading;
using TMPro;
using UnityEngine;

public class Planets : MonoBehaviour
{
    public THForce thf;
    public float rotateSpeed = 5;
    [SerializeField] private float speed;
    public float maxSpeed = 10;
    private Vector3 planetPos;
    public bool rotate;
    private Rigidbody2D rb;
    public float iceSpeed;
    public Transform planet;

    public float timerDuration = 5;
    private float timer;

    private void Awake() {
        rb = GetComponent<Rigidbody2D>();
    }

    private void FixedUpdate() {
        if(rotate)
            transform.RotateAround(planetPos, Vector3.forward, speed);
    }

    private void OnCollisionEnter2D(Collision2D collision) {
        if(collision != null && (collision.gameObject.CompareTag("P") || collision.gameObject.CompareTag("IP") || collision.gameObject.CompareTag("TP"))) {
            planet = collision.transform;
            rb.velocity = Vector2.zero;
            rb.angularVelocity = 0;
            Vector3 dir = planet.position - transform.position;
            float angle = (Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg) + 90;
            Quaternion q = Quaternion.AngleAxis(angle, Vector3.forward);
            Vector2 pos = collision.contacts[0].point;
            transform.SetPositionAndRotation(pos, q);
            planetPos = planet.position;
            thf.planet = true;
            if((Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.D)))
                thf.canJump = false;
            thf.m = 0 ;
            thf.STL = 0;
            thf.STR = 0;
            thf.SBL = 0;
            thf.SBR = 0;
            if(thf.PTL.isPlaying) thf.PTL.Stop();
            if(thf.PTR.isPlaying) thf.PTR.Stop();
            if(thf.PBL.isPlaying) thf.PBL.Stop();
            if(thf.PBR.isPlaying) thf.PBR.Stop();
            if(collision.gameObject.CompareTag("IP")) {
                iceSpeed = 0;
                print("reset ice");
            }
            rotate = true;
        }
    }
    private void OnCollisionStay2D(Collision2D collision) {
        if(collision != null && (collision.gameObject.CompareTag("P") || collision.gameObject.CompareTag("TP"))) {
            if(Input.GetKey(KeyCode.RightArrow))
                speed = -rotateSpeed;
            else if(Input.GetKey(KeyCode.LeftArrow))
                speed = rotateSpeed;
            else
                speed = 0;

        } else if(collision != null && collision.gameObject.CompareTag("IP")) {
            speed = iceSpeed;
            if(Input.GetKey(KeyCode.RightArrow) && iceSpeed <= 0 && iceSpeed > -maxSpeed)
                iceSpeed -= rotateSpeed / 10;
            else if(Input.GetKey(KeyCode.LeftArrow) && iceSpeed >= 0 && iceSpeed < maxSpeed)
                iceSpeed += rotateSpeed / 10;

        } else if(collision != null && collision.gameObject.CompareTag("S")) {
            thf.O.value -= 0.1f;
            if(thf.planet)thf.GetOffThePlanet(50);
        }
    }
}
