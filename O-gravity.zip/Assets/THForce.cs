using Cinemachine;
using UnityEngine;
using UnityEngine.UI;

public class THForce : MonoBehaviour {
    public Planets P;
    public CinemachineVirtualCamera c;
    public float planetDistance = 7;
    public float minDistance = 5;
    public float maxDistance = 10;
    public float speed;
    public Slider fuel;
    public Slider O;
    public ParticleSystem PTL;
    public ParticleSystem PTR;
    public ParticleSystem PBL;
    public ParticleSystem PBR;

    public float STL;
    public float STR;
    public float SBL;
    public float SBR;

    public float m = 0;
    public float O_m = 1;

    private Rigidbody2D rb;

    public bool planet;
    public bool canJump = true;

    void Awake() {
        rb = GetComponent<Rigidbody2D>();
        fuel.value = 100;
        O.value = 100;
    }

    void FixedUpdate() {
        rb.AddForce(STL * Time.deltaTime * (transform.up + transform.right).normalized);
        rb.AddTorque(STL / 1000);
        rb.AddForce(STR * Time.deltaTime * (transform.up - transform.right).normalized);
        rb.AddTorque(-STR / 1000);
        rb.AddForce(SBL * Time.deltaTime * (transform.right - transform.up).normalized);
        rb.AddTorque(-SBL / 1000);
        rb.AddForce(SBR * Time.deltaTime * (-transform.up - transform.right).normalized);
        rb.AddTorque(SBR / 1000);
    }

    // Update is called once per frame
    void Update() {
        if(fuel.value > 0) {

            if(planet && canJump && (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.D))){
                if(P.planet.CompareTag("IP")) {
                    if(P.iceSpeed == 0) {
                        GetOffThePlanet(300);
                    } else {
                        rb.velocity = Vector2.Perpendicular(P.planet.position - transform.position).normalized * -P.iceSpeed;
                        m = 0;
                        planet = false;
                        P.planet = null;
                        P.rotate = false;
                    }
                } else {
                    Debug.Log("lunch");
                    GetOffThePlanet(300);
                }
            } else if(planet &&!canJump&& (Input.GetKeyUp(KeyCode.W) || Input.GetKeyUp(KeyCode.A) || Input.GetKeyUp(KeyCode.S) || Input.GetKeyUp(KeyCode.D))){
                canJump = true;
            }else if(!planet) {
                //PTL.Stop(); PTR.Stop(); PBL.Stop();PBR.Stop();
                STL = 0; STR = 0; SBL = 0; SBR = 0; m = 0;
                if(Input.GetKey(KeyCode.W) ) {
                    m++;
                    STL = speed;
                    STR = speed;    
                    // if(!PBL.isPlaying) 
                    PBL.Play();
                    //if(!PBR.isPlaying) 
                    PBR.Play();
                }
                if(Input.GetKey(KeyCode.A) ) {
                    m++;
                    STL = speed;
                    SBR = speed;
                    //if(!PBL.isPlaying) 
                    PBL.Play();
                    //if(!PTR.isPlaying)
                    PTR.Play();

                    /*

                    if(planet && (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.Semicolon) || Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.L) || Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.P) || Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.Quote))) {
                        if(P.planet.CompareTag("IP")) {
                            print("IP");
                            print(P.iceSpeed == 0);
                            if(P.iceSpeed == 0)
                                GetOffThePlanet(300);
                            else {
                                rb.velocity = Vector2.Perpendicular(P.planet.position - transform.position).normalized * -P.iceSpeed;
                                m = 0;
                                planet = false;
                                P.planet = null;
                            }
                        } else {
                            GetOffThePlanet(300);
                        }
                    } else {
                        if(Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.Semicolon)) {
                            m++;
                            STL = speed;
                            STR = speed;
                            PBL.Play();
                            PBR.Play();
                        }
                        if(Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.L)) {
                            m++;
                            STL = speed;
                            SBL = speed;
                            PTL.Play();
                            PBL.Play();
                        }
                        if(Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.P)) {
                            m++;
                            SBL = speed;
                            SBR = speed;
                            PTL.Play();
                            PTR.Play();
                        }
                        if(Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.Quote)) {
                            m++;
                            SBR = speed;
                            STR = speed;
                            PTR.Play();
                            PBR.Play();
                        }
                    }
                    */
                }
                if(Input.GetKey(KeyCode.S)) {
                    m++;
                    SBL = speed;
                    SBR = speed;
                    //if(!PTL.isPlaying)
                    PTL.Play();
                    //if(!PTR.isPlaying)
                    PTR.Play();
                }
                if(Input.GetKey(KeyCode.D)) {
                    m++;
                    STR = speed;
                    SBL = speed;
                    //if(!PBR.isPlaying)
                    PBR.Play();
                    //if(!PTL.isPlaying)
                    PTL.Play();
                }
            }
            


            fuel.value -= m / 100;

            if(planet) {
                if(c.m_Lens.OrthographicSize > planetDistance)
                    c.m_Lens.OrthographicSize -= 0.1f;
                if(c.m_Follow == transform)
                    c.m_Follow = P.planet;
            } else {
                float dis = Mathf.Clamp(minDistance + (rb.velocity.magnitude / 2), minDistance, maxDistance);
                c.m_Lens.OrthographicSize = dis;

                if(c.m_Follow != transform)
                    c.m_Follow = transform;
            }

        } else {
            STL = 0;
            STR = 0;
            SBL = 0;
            SBR = 0;
            if(PTL.isPlaying) PTL.Stop();
            if(PTR.isPlaying) PTR.Stop();
            if(PBL.isPlaying) PBL.Stop();
            if(PBR.isPlaying) PBR.Stop();
        }
        /*
        if(Input.GetKeyUp(KeyCode.W) || Input.GetKeyUp(KeyCode.Semicolon)) {
            if(!Input.GetKey(KeyCode.D) && !Input.GetKey(KeyCode.L)) {
                PBL.Stop();
            }
            if(!Input.GetKey(KeyCode.A) && !Input.GetKey(KeyCode.Quote)) {
                PBR.Stop();
            }
        }
        if(Input.GetKeyUp(KeyCode.D) || Input.GetKeyUp(KeyCode.L)) {
            if(!Input.GetKey(KeyCode.W) && !Input.GetKey(KeyCode.Semicolon)) {
                PBL.Stop();
            }
            if(!Input.GetKey(KeyCode.S) && !Input.GetKey(KeyCode.P)) {
                PTL.Stop();
            }
        }
        if(Input.GetKeyUp(KeyCode.S) || Input.GetKeyUp(KeyCode.P)) {
            if(!Input.GetKey(KeyCode.D) && !Input.GetKey(KeyCode.L)) {
                PTL.Stop();
            }
            if(!Input.GetKey(KeyCode.A) && !Input.GetKey(KeyCode.Quote)) {
                PTR.Stop();
            }
        }
        if(Input.GetKeyUp(KeyCode.A) || Input.GetKeyUp(KeyCode.Quote)) {
            if(!Input.GetKey(KeyCode.S) && !Input.GetKey(KeyCode.P)) {
                PTL.Stop();
            }
            if(!Input.GetKey(KeyCode.W) && !Input.GetKey(KeyCode.Semicolon)) {
                PBR.Stop();
            }

        }
        */

        O.value -= Time.deltaTime * O_m;
        if(O.value <= 0.5f) {
            O.GetComponentInChildren<Image>().color = Color.red;
        }
        if(fuel.value <= 0.5f)
            fuel.GetComponentInChildren<Image>().color = Color.red;
    }

    public void GetOffThePlanet(int forcee) {
        rb.AddForce(speed * forcee * Time.deltaTime * (transform.up + transform.right).normalized);
        rb.AddTorque((speed * forcee) / 1000);
        rb.AddForce(speed * forcee * Time.deltaTime * (transform.up - transform.right).normalized);
        rb.AddTorque(-(speed * forcee) / 1000);
        m = 0;
        planet = false;
        P.planet = null;
        P.rotate = false;
    }
}
