using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Bomb : MonoBehaviour
{
    public float time;
    TextMeshProUGUI text; 
    bool timer = false;
    bool inn;
    GameObject player;
    private void Start() {
        text = transform.GetChild(0).GetChild(0).GetComponent<TextMeshProUGUI>();
    }
    void Update() {
        if(timer) {
            time -= Time.deltaTime;
            text.text = time.ToString("0.0");
        }
        if(time <= 0) {
            if(inn) {
                player.GetComponent<THForce>().O.value -= 20;
                player.GetComponent<THForce>().GetOffThePlanet(300);
            }
            Destroy(gameObject);
        }
    }
    private void OnCollisionEnter2D(Collision2D collision) {
        if(collision.gameObject.CompareTag("Player")) {
            timer = true;
            player = collision.gameObject;
            inn = true;
        }
    }
    private void OnCollisionExit2D(Collision2D collision) {
        if(collision.gameObject.CompareTag("Player")) {
            inn = false;
        }
    }
}
